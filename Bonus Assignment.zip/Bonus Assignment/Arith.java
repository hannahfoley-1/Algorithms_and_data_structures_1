// -------------------------------------------------------------------------
/**
 *  Utility class containing validation/evaluation/conversion operations
 *  for infix arithmetic expressions.
 *
 *  @author Hannah Foley
 *  @version 1/12/15 13:03:48
 *  REFERENCE
 *  https://www.javatpoint.com/java-string-to-int
 *  https://algorithms.tutorialhorizon.com/evaluation-of-infix-expressions/
 *  https://panda.ime.usp.br/panda/static/pythonds_pt/02-EDBasicos/InfixPrefixandPostfixExpressions.html#conversion-of-infix-expressions-to-prefix-and-postfix
 */
import java.util.ArrayList;
import java.util.Stack;

public class Arith
{
    public static String opBracket = "(";
    public static String closBracket = ")";
    public static String plus = "+";
    public static String minus = "-";
    public static String mul = "*";
    public static String div = "/";
    //~ Validation methods ..........................................................


    /**
     * Validation method for infix notation.
     *
     * @param infixLiterals : an array containing the string literals hopefully in infix order.
     * The method assumes that each of these literals can be one of:
     * - "+", "-", "*", or "/"
     * - or a valid string representation of an integer "0", "1" , "2", ..., "-1", "-2", ...
     *
     * @return true if the parameter is indeed in infix notation, and false otherwise.
     **/
    public static boolean validateInfixOrder(String infixLiterals[])
    {
        //TODO
        /** To validate brackets I will use a braket counter, it will increment by one for each open bracket
         * and decrement by one for each closing bracket
         * The bracket number should never go below 0 and at the end after each character has been compared
         * the bracket count should =0 meaning all opening brackets had a corresponding closing btaclet
         *
         * No two operators can be beside each other so once an operator is found the operator boolean will be
         * set to true to make sure the operators are surrounded by numbers only
         *
         * A number must be followed by a bracket or a operator so the number boolean will set to true if a number
         * is encountered
         *
         */
        boolean operator = false;
        int bracketCount = 0;
        boolean number = false;

          for (int i = 0; i < infixLiterals.length; i++) {
              if (infixLiterals[i].equals(opBracket))
              {
                  bracketCount++;
              }
              else if (infixLiterals[i].equals(closBracket))
              {
                  bracketCount--;
              }
              else if (bracketCount < 0)
              {
                  return false;
              }
              else if (infixLiterals[i].equals(plus) || infixLiterals[i].equals(minus) || infixLiterals[i].equals(mul)
                      || infixLiterals[i].equals(div))
              {
                  if(operator)
                  {
                      return false;
                  }
                  number = false;
                  operator = true;
              }
              else
              {
                  number = true;
                  operator = false;
              }
          }
         //all elements have been checked
        if (bracketCount == 0)
        {
            return true;
        }
        return false;
    }


    //~ Evaluation  methods ..........................................................


    /**
     * Evaluation method for infix notation.
     *
     * @param infixLiterals : an array containing the string literals in infix order.
     * The method assumes that each of these literals can be one of:
     * - "+", "-", "*", or "/"
     * - or a valid string representation of an integer.
     *
     * @return the integer result of evaluating the expression
     **/
    public static int evaluateInfixOrder(String infixLiterals[]) {
        /*
            I will use stacks
            One for numbers
            One for operators
            Pop 2 values from the number stack
            Pop one from operators
            Perform operation
            Push this number back onto the number stack
         */
        /** Do what is inside its own brackets first
         * Find items that may be an operand with two numbers either side inside a pair of brackets
         *  -Find an opening bracket
         *  -Only continue if the next element is a number, save it
         *  -Only continue if the next element is an operator, save it
         *  -Only continue is the next element is a number, save it
         *  -Only continue if the next element in a closing bracket, save it
         *  -Calculate this
         *  -Create new array with all the same elements up to the opening bracket, then leave a blank
         *  element, then after the closing bracket, continue to copy over the elements
         *  -Replace in the space of the blank element, the new number calculated
         *
         * Repeat this until there are no brackets left, there should only be two numbers and an operand,
         * Calculate this and return it
         *
         */
        Stack<Integer> numbers = new Stack<Integer>();
        Stack<String> operations = new Stack<String>();

        for (int i = 0; i < infixLiterals.length; i++) {
            if (isNumber(infixLiterals[i])) {
                int number = 0;
                int currDig = 0;
                int by = 1;
                for (int j = 0; j < infixLiterals[i].length(); j++) {
                    char n = (char) infixLiterals[i].charAt(j);
                    currDig = convertToInt(n);
                    if (currDig == 0)
                    {
                        number *= by;
                    }
                    else
                    {
                        number += currDig * by;
                    }
                    by *= 10;
                }
                numbers.push(number);
            } else if (infixLiterals[i].equals(opBracket)) {
                operations.push(infixLiterals[i]);
            } else if (infixLiterals[i].equals(closBracket)) {
                while (operations.peek() != "(") {
                    int result = calculate(numbers, operations);
                    numbers.push(result);
                }
                operations.pop();
            }
            else if (isOperator(infixLiterals[i])) {
                while (!operations.isEmpty() &&
                        precedence(infixLiterals[i]) <= precedence(operations.peek())) {
                    int result = calculate(numbers, operations);
                    numbers.push(result);
                }
                operations.push(infixLiterals[i]);
            }
        }//each element has been processed and put on stack

        while(!operations.isEmpty())
        {
            int result = calculate(numbers, operations);
            numbers.push(result);
        }
        return numbers.pop();
    }


    private static boolean isNumber(String next) {
        if (next.equals(minus) || next.equals(opBracket) || next.equals(closBracket)
                || next.equals(plus) || next.equals(mul) || next.equals(div)) {
            return false;
        }
        return true;
    }

    private static int convertToInt(char num){
        switch(num){
            case '0' : return 0;
            case '1' : return 1;
            case '2' : return 2;
            case '3' : return 3;
            case '4' : return 4;
            case '5' : return 5;
            case '6' : return 6;
            case '7' : return 7;
            case '8' : return 8;
            case '9' : return 9;
            default : return 0;
        }
    }

    private static int calculate (Stack<Integer> numbers,Stack<String> operations) {
        int no1 = numbers.pop();
        int no2 = numbers.pop();
        String operation = operations.pop();
        switch(operation) {
            case "+": return no1 + no2;
            case "-": return no2 - no1;
            case "*": return no1 * no2;
            case "/":
                if (no1 == 0)
                {
                    System.err.print("Error: Division by 0");
                    return 0;
                }
                return no2/no1;
            default : return 0;
        }
    }



    private static boolean isOperator(String str)
    {
        if (str.equals(mul) || str.equals(plus) || str.equals(div) ||
        str.equals(minus))
        {
            return true;
        }
        return false;
    }

    private static int precedence(String c){
        switch (c){
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
                return 2;
        }
        return -1;
    }


    //~ Conversion  methods ..........................................................


    /**
     * Converts infix to postfix.
     *
     * @param infixLiterals : an array containing the string literals in infix order.
     * The method assumes that each of these literals can be one of:
     * - "+", "-", "*", or "/"
     * - or a valid string representation of an integer.
     *
     * @return the expression in postfix order.
     **/
    public static String[] convertInfixToPostfix(String infixLiterals[])
    {
        Stack<String> operations =  new Stack<>();
        ArrayList<String> asPostfix = new ArrayList<>();

        for (int i = 0; i < infixLiterals.length; i++)
        {
            if (isNumber(infixLiterals[i]))
            {
                asPostfix.add(infixLiterals[i]);
            }
            else if (infixLiterals[i].equals(opBracket))
            {
                operations.push(infixLiterals[i]);
            }
            else if (infixLiterals[i].equals(closBracket))
            {
                String popped = operations.pop();
                while (!operations.empty() && !popped.equals(opBracket))
                {
                    asPostfix.add(popped);
                    popped = operations.pop();
                }
            }
            if(infixLiterals[i].equals(plus) || infixLiterals[i].equals(minus) ||
                    infixLiterals[i].equals(div) || infixLiterals[i].equals(mul))
            {
                while(!operations.empty() && precedence(infixLiterals[i]) <= precedence(operations.peek())) {
                    asPostfix.add(operations.pop());
                }
                operations.push(infixLiterals[i]);
            }
        }
        while (!operations.empty())
        {
            asPostfix.add(operations.pop());
        }
        String[] asPostfixArray = new String[asPostfix.size()];
        for (int i = 0; i < asPostfix.size(); i++)
        {
            asPostfixArray[i] = asPostfix.get(i);
        }
        return asPostfixArray;
    }


    /**
     * Converts postfix to infix.
     *
     * @param postfixLiterals : an array containing the string literals in postfix order.
     * The method assumes that each of these literals can be one of:
     * - "+", "-", "*", or "/"
     * - or a valid string representation of an integer.
     *
     * @return the expression in infix order.
     **/
    public static String[] convertPostfixToInfix(String postfixLiterals[])
    {
        Stack<String> numbers =  new Stack<>();

        for (int i = 0; i < postfixLiterals.length; i++)
        {
            if (isNumber(postfixLiterals[i]))
            {
                numbers.push(postfixLiterals[i]);
            }
            else if(postfixLiterals[i].equals(plus) || postfixLiterals[i].equals(minus) ||
                    postfixLiterals[i].equals(div) || postfixLiterals[i].equals(mul))
            {
                String numsAndOperator = "";
                String num1 = numbers.pop();
                String num2 = numbers.pop();
                numsAndOperator = "(" + num2 + postfixLiterals[i] + num1 + ")";
                numbers.push(numsAndOperator);
            }
        }
        String asInfixString = numbers.pop();
        ArrayList<String> asInfix = new ArrayList<>();

        for (int j = 0; j < asInfixString.length(); j++)
        {
            //if the character is a number greater than 1 digit
            //make this a while loop instead
            if(isNumber(String.valueOf(asInfixString.charAt(j))) && isNumber(String.valueOf(asInfixString.charAt(j+1))))
            {
                String value = String.valueOf(asInfixString.charAt(j)) + String.valueOf(asInfixString.charAt(j+1));
                asInfix.add(value);
                j++;
            }
            else
            {
                asInfix.add(String.valueOf(asInfixString.charAt(j)));
            }
        }
        String[] asInfixArray = new String[asInfix.size()];
        for (int i = 0; i < asInfix.size(); i++)
        {
            asInfixArray[i] = asInfix.get(i);
        }
        return asInfixArray;
    }



}