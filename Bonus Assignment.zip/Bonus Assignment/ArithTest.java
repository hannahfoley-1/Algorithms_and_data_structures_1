import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;


@RunWith(JUnit4.class)
public class ArithTest {

    @Test
    public void testValidateInfixOrder(){
        Arith arith = new Arith();
        String[] array = {"(", "(", "(", "1", "-", "2", ")", "+", "(", "-", "(", "3", "+", "6", "/",
                "3", ")", ")", ")", ")"};
        boolean valid = arith.validateInfixOrder(array);
        assertEquals("Testing with invalid array", false, valid);

        String[] array2 = {"(", "(", "(", "1", "-", "2", ")", "*", "3", ")", "+", "(", "10", "-", "(", "3", "+",
        "(", "6", "/", "3", ")", ")", ")", ")"};
        assertEquals("Testing with valid array", true, arith.validateInfixOrder(array2));

        //test with an array where the bracket count gets to less than 0 during testing
        String[] array3 = {"(" , "(", "(", "(", "1", "-", "2", ")", "*", "3", ")", ")", ")", ")", "+", "(", "10", "-", "(", "3", "+",
                "(", "6", "/", "3", ")", ")", ")", ")"};
        assertEquals("Testing with an array that the bracket count reaches below 0 during testing", false,
                arith.validateInfixOrder(array3));

        //test with an array where the bracket count != 0 at the end
        String[] array4 = {"(", "(", "(", "(", "1", "-", "2", ")", "*", "3", "+", "(", "10", "-", "(", "3", "+",
                "(", "6", "/", "3", ")", ")"};
        assertEquals("Testing where bracket count at the end != 0", false, arith.validateInfixOrder(array4));
    }

    @Test
    public void testEvaluateInfixOrder(){
        Arith arith = new Arith();
        String[] array = {"(", "(", "(", "1", "-", "2", ")", "*", "3", ")", "+", "(", "10", "-", "(", "3", "+",
                "(", "6", "/", "3", ")", ")", ")", ")"};
        assertEquals("Testing with valid array", 2, arith.evaluateInfixOrder(array));

    }

    @Test
    public void testConvertnfixToPostfix(){
        Arith arith = new Arith();
        String[] array = {"(", "(", "(", "1", "-", "2", ")", "*", "3", ")", "+", "(", "10", "-", "(", "3", "+",
                "(", "6", "/", "3", ")", ")", ")", ")"};
        String[] expected = {"1", "2", "-", "3", "*", "10", "3", "6", "3", "/", "+", "-", "+"};
        assertEquals("Testing with valid array", expected, arith.convertInfixToPostfix(array));
    }

    @Test
    public void testConvertPostfixToInfix(){
        Arith arith = new Arith();
        String[] array = {"1", "2", "-", "3", "*", "10", "3", "6", "3", "/", "+", "-", "+"};
        String [] expected = {"(", "(", "(", "1", "-", "2", ")", "*", "3", ")", "+", "(", "10", "-", "(", "3", "+",
                "(", "6", "/", "3", ")", ")", ")", ")"};
        assertEquals("Testing with valid array", expected, arith.convertPostfixToInfix(array));
    }



}



